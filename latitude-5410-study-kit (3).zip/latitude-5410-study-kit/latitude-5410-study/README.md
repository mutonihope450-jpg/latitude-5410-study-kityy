# Dell Latitude 5410 Study Kit

A small website that teaches the parts inside a Dell Latitude 5410 and tests what you learned.
It has no build step. Every page is plain HTML.

## Files

| File | What it is |
|---|---|
| `index.html` | Home page with two buttons |
| `inside.html` | Parts explorer (English and Kinyarwanda) |
| `test.html` | Knowledge check: written test and practical checklist |
| `.gitignore` | Tells Git which files never to upload |

## Run it on your computer

Double-click `index.html`. It opens in your browser. You do not need internet.

## Live site

Replace this line with your link after you deploy:

https://YOUR-PROJECT.vercel.app

## How it gets on the web

1. You change a file and run `git push`.
2. GitHub stores the new version.
3. Vercel sees the push and publishes the new version by itself.
